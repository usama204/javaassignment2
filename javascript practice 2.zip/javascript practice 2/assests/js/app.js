
// Chapter 01

// 1. Write a script to greet your website visitor using JS alert  box

// 2. Write a script to display following message on your web  page
 alert(
     'Java Script Alert error \n ! please enter a  valid password',
     '',
     ''
   )

// //    Write a script to display following message on your web page: (Hint : Use line break)
 alert(
     'Java Script Alert \n welcome to JS Land  Happy Coding',
     '',
     ''
   )
// //   4. Write a script to display following messages in sequence:
 alert(
     'Java Script Alert \n welcome to JS Land ',
     '',
     '')

 alert(
     'Happy Coding \n Prevent this page from creating',
     '',
     ''
   )
 //   5. Generate the following message through browser’s developer console:
 alert(
     'Java Script Alert \n Hello I can run  JS through my web browser console',
     '',
     ''
   )


//   Chapter 02

//   Declare a variable called username.
 var username;

// 2. Declare a variable called myName & assign to it a string that represents your Full Name.

 var myname = "Usama Kasabti"

// 3. Write script to
// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box.

 var message = "Hello World"

 alert(message);

// 4. Write a script to save student’s bio data in JS variables and show the data in alert boxes.

 Swal.fire(
     'Jhone Doe',
     '',
     ''
   )
   alert(
     "15 YEARS old"
   )
   alert(
     "Certifiate Mobile Application Development"
   )

   alert(
     "pizza \n PIZZ \n PIZ \n PI \n P ")
 alert(
     "My email address is usamakasbati123@gmail.com")
 alert(
    "smarter way to learn JavaScript" )

// chapter 2 end

// chapter 03 start

// 1. Declare a variable called age & assign to it your age. Show
// your age in an alert box.

var age = "I am 15 years old"
alert(age)

// 2. Declare & initialize a variable to keep track of how many
// times a visitor has visited a web page. Show his/her
// number of visits on your web page.


 var webpage = "You have visited this site 15 times"
  alert(webpage)

//  3. Declare a variable called birthYear & assign to it your
// birth year. Show the following message in your browser:

 var birthyear = "my birth year is 2004"
 document.write(birthyear)

// 4. A visitor visits an online clothing store
// www.xyzClothing.com . Write a script to store in variables
// the following 
// a. Visitor’s name

 var  visitorsName = "Usama Kasabti"



// b. Product title

 var  productTitle = "Shoes"


// c. Quantity i.e. how many products a visitor wants to order:

 var orderno = 3

 document.write(visitorsName + " " + "ordered" + " " + orderno + " " + productTitle + " "+ "on outfitters" )





// Chapter 04
// 1. Declare 3 variables in one statement.

 var num1 = 10,num2 = 20,num3 = 50

// 2. Declare 5 legal & 5 illegal variable names.

 var 12num 
 var @num 
 var 'num 
 var /num 
 var 14num

 var fullName;
var lastName;
 var firstName;
 var lastName;
 var name;

// 3. Display this in your browser
var fullname = "Rules for naming JS variables"
 document.write(fullname);

var lastname = " <br> <br> <br> <br> Variable names can only contain , number,$ and _.  $my_1stVariable"
document.write(lastname)

var firstName = " <br> Variables must begin with a letter$ and $Usama,Usama,Kasbati"
document.write(firstName)

var lastName = " <br> variable names are case sensitive"
document.write(lastName)

var name = " <br> Variable names should not be JS Keyword "
document.write(name)


// chapter 4 end

// chapter 5
// 1. Write a program that take two numbers & add them in a new variable. Show the result in your browser.


 var  num1 = 5
var num2 =3

// console.log(num1 + num2)

// 2. Repeat task1 for subtraction, multiplication, division &modulus.


// subtraction

 var  num1 = 5
var num2 =3

 console.log(num1 - num2)

// multiplication


 var  num1 = 5
 var num2 =3

 console.log(num1 * num2)



// division
var  num1 = 15
 var num2 =5

console.log(num1 / num2)

// modulus

 var  num1 = 15
var num2 =4

 console.log(num1 % num2)



// 3. Do the following using JS Mathematic Expressions


// a. Declare a variable.

 var value;


//  b. Show the value of variable in your browser like “Value  after variable declaration is: ??”.
//  c. Initialize the variable with some number.
//  d. Show the value of variable in your browser like “Initial value: 5”.


var value = 5;
document.write("Intial Value:", " ",  value);

// e. Increment the variable.
// f. Show the value of variable in your browser like “Value
// after increment is: 6”.

document.write("<br> value after increment is:" ,++value)

// g. Add 7 to the variable.
// h. Show the value of variable in your browser like “Value after addition is: 13”.

 var value1 = 7

// document.write("<br> value after addition:" ,value + value1 )

// i. Decrement the variable.
// j. Show the value of variable in your browser like “Value
// after decrement is: 12”.

document.write("<br> value after decrement is:" ,--value1 + value)

// k. Show the remainder after dividing the variable’s value 
// by 3. 
// l. Output : “The remainder is : 0”.

 document.write("<br> The Remainder is:" , value % value1)




// Q4. Cost of one movie ticket is 600 PKR. Write a script to store
// ticket price in a variable & calculate the cost of buying 5 
// tickets
// to a movie.


var  num1 = 600
 var num2 =5

document.write( "Total cost to buy 5 tickets to a movie is", num1 * num2 ,"PKR")



// Assigment Js 02
// Chapter 1 (Alerts)
// 3. Code an alert statement displaying any message you like.

// 1. Alert these following (individually): 
// I. First Name

var firstName = "Usama"
 alert(firstName)

// II. Last Name
 var lastName = "Kasbati"
 alert(lastName)

// III. Email
var Email = "usamakasabti@gmail.com"
alert(Email)

// IV. Phone Number
var phoneNumber = 03172879104
alert(phoneNumber)

// V. Password
var Password = "valcal"
 alert(Password)

// 2. Correct this statement: alert"You're learning JavaScript!";

alert("You are learning javascript");


// Chapter 2 (Variables for string)


// 1. Declare any variable in the camelCase format.
// 2. Declare a variable of your choice without defining it. Then, in a 
// second statement, assign it a string of your choice.

var assign;
assign = "Hello Java Script"

// 3. Declare the variable teamName and Alert your Team name.

var teamName = "Pakistan"
 alert(teamName)

// 4. This statement has already been coded. var bestMan = "Charlie";
// Assign the variable a new string.

 var bestPlayer = "Babar Azam"


// Chapter 3 (Variables for numbers)

//  1. Declare a variable “caseQty”

var caseQty;

// 2. Assign to the variable caseQty, which has already been declared, 
// the value 144.

// caseQty = 144;

// 3. Rewrite this statement so the variable can be used in a math 
// operation;

 var num = "9"

// 4. In one statement declare a variable. In a second statement assign 
// it the sum of 2 numbers.


document.write(caseQty + num)


// 5. What is the value of orderTotal?
 var merchTotal = 100;
 var shippingCharge = 10;
 var orderTotal = merchTotal + shippingCharge;

 var merchTotal = 100;
 var shippingCharge = 10;
 var orderTotal = merchTotal + shippingCharge;

 document.write(orderTotal);

// 6. In the first statement declare a variable and assign it a number. In 
// the second statement, change the value of the variable by adding 
// it together with a number.

 var firstStatement = 120;
 var secondStatement = 30;

 var totalNum = firstStatement + secondStatement;

 document.write(totalNum)



// Chapter 4 (Variable names Legal and Illegal)

// 1. Correct this statement.
 var product cost = 3.45;

 var productCost = 3.45;


// 2. Rewrite this using camelCase.
 var Nameofband;

var nameOfBand;

// 3. In a single statement declare a legally-named variable and assign a 
// number to it.

var 1product = 76;

// 4. Declare a variable that is a combination of your first and last 
// names. Use camelCase.

 var firstName = "Usama"
 var lastName = "Kasbati"


// 5. List the legal and Illegal Variables.

 var 12num = 12
 var @num = usama
 var 'num = 15
 var /num = 14
 var 14num = 13

 var fullName;
 var lastName;
 var firstName;
 var lastName;
 var name;


// Chapter 5 (Math Expression I)


// 1. What is the name and symbol of the arithmetic operator that 
// gives you the remainder when one number is divided by another?

// Definition
// The arithmetic operator that gives you the remainder when one number is
//  divided by another is called the "modulo" operator. In mathematics and
//   programming, it is often represented by the symbol "%" (percent sign).

 var module1 = 10;
 var module2 = 3;

document.write(module1 % module2);


// 2. What is the value of num?
 var num = 20 % 6;

 var num = 20 % 6;
 the value of num = 2;
 document.write(num);


// 3. In a single statement, declare the variable largeNum and assign it 
// the result of 1,000 multiplied by 2,000.


 var largeNum = 1000;
 var result = 2000;
 document.write(largeNum * result);


// 4. Assign to a variable the value represented by one variable 
// subtracted from the value represented by another variable

 var subtract = 35;
 var subtract1 = 25;

document.write(subtract - subtract1);

// 5. Assign to a variable the remainder when one number is divided by 
// another. The variable hasn't been declared beforehand. Make up 
// the variable nam


























 